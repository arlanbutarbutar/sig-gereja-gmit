<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?= $_SESSION['page-name'] ?> - SIG Gereja GMIT</title>
<link rel="stylesheet" href="../assets/feather/feather.css">
<link rel="stylesheet" href="../assets/css/materialdesignicons.min.css">
<link rel="stylesheet" href="../assets/css/themify-icons.css">
<link rel="stylesheet" href="../assets/css/typicons.css">
<link rel="stylesheet" href="../assets/simple-line-icons/css/simple-line-icons.css">
<link rel="stylesheet" href="../assets/css/vendor.bundle.base.css">
<link rel="stylesheet" href="../assets/css/style-dash.css">
<link rel="shortcut icon" href="../assets/img/logo.png" />
<script src="../assets/sweetalert/dist/sweetalert2.all.min.js"></script>