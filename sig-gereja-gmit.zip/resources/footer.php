<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.25s">
        <p>© Copyright <?= date('Y'); ?> Netmedia Framecode. All Rights Reserved.

          <br>Powered by <a rel="nofollow" href="https://sig-gereja-gmit.tugasakhir.my.id">Joseph Bayutara Abolaki</a>
        </p>
      </div>
    </div>
  </div>
</footer>
<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/animation.js"></script>
<script src="assets/js/imagesloaded.js"></script>
<script src="assets/js/templatemo-custom.js"></script>